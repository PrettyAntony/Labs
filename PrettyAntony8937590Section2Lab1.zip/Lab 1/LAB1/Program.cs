﻿// Pretty Antony -- 8935790 -- Section 2

namespace LAB1;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}
