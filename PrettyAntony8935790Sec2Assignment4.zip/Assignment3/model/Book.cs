public class Book
{
    public string? bookName { get; set; }
    public string? authorName { get; set; }
    public string? publicationYear { get; set; }
    public string? genre { get; set; }

    //Poetry, fiction, nonfiction, drama, and prose
}