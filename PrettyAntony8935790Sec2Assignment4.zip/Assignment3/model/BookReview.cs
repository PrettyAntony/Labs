public class BookReview : Book
{
    public string? reviewerFirstName { get; set; }
    public string? reviewerLastName {get; set;}
    public string? reviewerEmail { get; set; }
    public string? reviewText{get; set;}
    public string? rating{get; set;}

    public BookReview(){
        //empty constructor
    }

    public BookReview(string _bookName, string _authorName, string _publicationYear, string _genre, string _reviewerFirstName, string _reviewerLastName, string _reviewerEmail, string _reviewText, string _rating){
        this.bookName = _bookName;
        this.authorName = _authorName;
        this.publicationYear = _publicationYear;
        this.genre = _genre;
        this.reviewerFirstName = _reviewerFirstName;
        this.reviewerLastName = _reviewerLastName;
        this.reviewerEmail = _reviewerEmail;
        this.reviewText = _reviewText;
        this.rating = _rating;
    }

    public string getReviewerName(){
        return reviewerFirstName+" "+reviewerLastName;
    }

}