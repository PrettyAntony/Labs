using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text.Json;

namespace Assignment3.Pages
{
    public class SubmitReviewModel : PageModel
    {
        public BookReview bookReview = new BookReview();

        private const string saveReviewsFilePath = "review.json";

        public void OnGet()
        {
        }

        public IActionResult OnPost(BookReview bookReview)
        {

            //get all saved reviews and save the new 
            loadExistingListAndSaveNewReview(bookReview);

            //on save clicked, the page redirects to see the last saved review
            return RedirectToPage("Privacy", bookReview);
        }

        private void loadExistingListAndSaveNewReview(BookReview review)
        {
            //getting all saved reviews and adding new review
            List<BookReview> savedReviews = loadAllSavedReviews();

            savedReviews.Add(review);

            saveReviews(savedReviews);

        }

        private List<BookReview> loadAllSavedReviews()
        {
            try
            {
                //checking if file exists and fetch all saved reviews
                if (System.IO.File.Exists(saveReviewsFilePath))
                {
                    string json = System.IO.File.ReadAllText(saveReviewsFilePath);
                    return JsonSerializer.Deserialize<List<BookReview>>(json)!;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return new List<BookReview>();
        }

        //save reviews to file path
        private void saveReviews(List<BookReview> reviews)
        {
            string json = JsonSerializer.Serialize(reviews, new JsonSerializerOptions { WriteIndented = true });

            System.IO.File.WriteAllText(saveReviewsFilePath, json);
        }


    }
}
