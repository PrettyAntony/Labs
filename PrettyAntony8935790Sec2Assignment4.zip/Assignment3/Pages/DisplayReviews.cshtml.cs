using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text.Json;

namespace Assignment3.Pages
{
    public class DisplayReviewsModel : PageModel
    {
        public List<BookReview> bookReviewList = new List<BookReview>();

        private const string saveReviewsFilePath = "review.json";

        public void OnGet()
        {
            //getting all saved reviews and adding new review
            List<BookReview> savedReviews = loadAllSavedReviews();

            bookReviewList = savedReviews;

        }

        private List<BookReview> loadAllSavedReviews()
        {
            try
            {
                //checking if file exists and fetch all saved reviews
                if (System.IO.File.Exists(saveReviewsFilePath))
                {
                    string json = System.IO.File.ReadAllText(saveReviewsFilePath);
                    return JsonSerializer.Deserialize<List<BookReview>>(json)!;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return new List<BookReview>();
        }
    }
}
